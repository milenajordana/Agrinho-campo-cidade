let player;
let food = [];
let obstacles = [];
let cityX;
let score = 0;
let gameState = "play";

function setup() {
  createCanvas(800, 400);
  player = createVector(100, height - 60);
  cityX = width - 100;

  // Gerar comida no campo
  for (let i = 0; i < 5; i++) {
    food.push(createVector(random(50, 200), height - 60));
  }

  // Obstáculos entre campo e cidade
  for (let i = 0; i < 6; i++) {
    obstacles.push(createVector(random(250, 700), height - 60));
  }
}

function draw() {
  background(180, 220, 180);

  if (gameState === "play") {
    drawField();
    drawPlayer();
    drawFood();
    drawObstacles();
    drawCity();

    checkCollisions();
    checkWin();
  } else if (gameState === "win") {
    background(100, 200, 100);
    fill(255);
    textSize(32);
    textAlign(CENTER);
    text("Você Conectou o Campo à Cidade!", width / 2, height / 2);
  }
}

function drawField() {
  fill(120, 200, 120);
  rect(0, height - 40, width, 40);
}

function drawPlayer() {
  fill(255, 150, 0);
  rect(player.x, player.y, 30, 30);
}

function drawFood() {
  fill(255, 0, 0);
  for (let i = 0; i < food.length; i++) {
    ellipse(food[i].x, food[i].y, 15, 15);
  }
}

function drawObstacles() {
  fill(100);
  for (let i = 0; i < obstacles.length; i++) {
    rect(obstacles[i].x, obstacles[i].y, 20, 20);
  }
}

function drawCity() {
  fill(80, 80, 200);
  rect(cityX, height - 100, 60, 100);
  fill(255);
  textAlign(CENTER);
  text("CIDADE", cityX + 30, height - 110);
}

function keyPressed() {
  if (keyCode === RIGHT_ARROW) {
    player.x += 10;
  }
  if (keyCode === LEFT_ARROW) {
    player.x -= 10;
  }
}

function checkCollisions() {
  for (let i = food.length - 1; i >= 0; i--) {
    if (dist(player.x, player.y, food[i].x, food[i].y) < 20) {
      food.splice(i, 1);
      score++;
    }
  }

  for (let obs of obstacles) {
    if (dist(player.x, player.y, obs.x, obs.y) < 20) {
      player.x = 100;
      score = 0;
      food = [];
      for (let i = 0; i < 5; i++) {
        food.push(createVector(random(50, 200), height - 60));
      }
      break;
    }
  }
}

function checkWin() {
  if (score >= 5 && player.x > cityX) {
    gameState = "win";
  }
}
